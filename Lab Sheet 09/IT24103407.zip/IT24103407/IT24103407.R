setwd("C:\\Users\\ISURU\\Desktop\\IT24103407")

y <- rnorm(25, mean = 45, sd = 2)
print(y)

t.test(y, mu = 46, alternative = "less")
